
-- --------------------------------------------------------

--
-- Table structure for table `prof_categories`
--

CREATE TABLE `prof_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(42) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `prof_categories`
--

INSERT INTO `prof_categories` (`id`, `name`) VALUES
(1, 'Adel'),
(2, 'Angestellte'),
(3, 'Beamte'),
(4, 'Handel'),
(5, 'Handwerk'),
(6, 'Künstler'),
(7, 'Militär'),
(8, 'Rentner'),
(9, 'Selbständig'),
(10, 'Sonstiges'),
(11, 'Unbekannt');
