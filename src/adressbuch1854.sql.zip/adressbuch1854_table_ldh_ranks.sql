
-- --------------------------------------------------------

--
-- Table structure for table `ldh_ranks`
--

CREATE TABLE `ldh_ranks` (
  `id` int(11) NOT NULL,
  `rank` varchar(42) DEFAULT NULL,
  `index_no` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ldh_ranks`
--

INSERT INTO `ldh_ranks` (`id`, `rank`, `index_no`) VALUES
(1, 'Chevalier', 1),
(2, 'Commandeur', 2),
(3, 'Officier', 3),
(4, 'Grand Officier', 4),
(5, 'Grand-Croix', 5),
(6, 'Unbekannt', 6);
