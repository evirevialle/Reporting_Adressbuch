
-- --------------------------------------------------------

--
-- Table structure for table `occupation_statuses`
--

CREATE TABLE `occupation_statuses` (
  `id` int(11) NOT NULL,
  `status` varchar(42) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `occupation_statuses`
--

INSERT INTO `occupation_statuses` (`id`, `status`) VALUES
(1, 'Active'),
(2, 'Pensioner'),
(3, 'Annuitant');
