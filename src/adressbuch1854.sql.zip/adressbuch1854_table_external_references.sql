
-- --------------------------------------------------------

--
-- Table structure for table `external_references`
--

CREATE TABLE `external_references` (
  `id` int(11) NOT NULL,
  `reference` varchar(128) DEFAULT NULL,
  `short_description` varchar(256) DEFAULT NULL,
  `link` varchar(512) DEFAULT NULL,
  `reference_type_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `external_references`
--

INSERT INTO `external_references` (`id`, `reference`, `short_description`, `link`, `reference_type_id`) VALUES
(1, 'link', 'Ehrenlegion', 'https://de.wikipedia.org/wiki/Ehrenlegion', 1),
(2, 'artikel', 'König, Mareike. « Georg Kibler, Möbelbauer, Rue de Charonne 39: Adreßbuch der Deutschen in Paris für das Jahr 1854 »', 'https://francia.digitale-sammlungen.de//Blatt_bsb00016434,00157.html', 2),
(3, 'Occupation Title beamte', 'History of work information', 'https://historyofwork.iisg.nl/detail_hiswi.php?know_id=9385&lang=GE', 1),
(4, 'Occupation Title handel mannlich', 'History of work information', 'https://historyofwork.iisg.nl/detail_hiswi.php?know_id=9672&lang=GE', 1),
(5, 'Occupation Title handel Frau', 'History of work information', 'https://historyofwork.iisg.nl/detail_hiswi.php?know_id=10471&lang=GE', 1),
(6, 'Occupation Title künstler', 'History of work information', 'https://historyofwork.iisg.nl/detail_hiswi.php?know_id=9832&lang=GE', 1),
(7, 'Occupation Title rentier', 'History of work information', 'https://historyofwork.iisg.nl/detail_hiswi.php?know_id=10115&lang=GE', 1),
(8, 'Occupation Title rentner', 'History of work information', 'https://historyofwork.iisg.nl/detail_hiswi.php?know_id=10117&lang=GE', 1);
