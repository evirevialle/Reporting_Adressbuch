
-- --------------------------------------------------------

--
-- Table structure for table `military_statuses`
--

CREATE TABLE `military_statuses` (
  `id` int(11) NOT NULL,
  `status` varchar(42) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `military_statuses`
--

INSERT INTO `military_statuses` (`id`, `status`) VALUES
(1, 'Military'),
(2, 'Civil');
