
-- --------------------------------------------------------

--
-- Table structure for table `social_statuses`
--

CREATE TABLE `social_statuses` (
  `id` int(11) NOT NULL,
  `status` varchar(42) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `social_statuses`
--

INSERT INTO `social_statuses` (`id`, `status`) VALUES
(1, 'Commoner'),
(2, 'Noble'),
(3, 'Clergy');
