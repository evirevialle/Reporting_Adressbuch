
-- --------------------------------------------------------

--
-- Table structure for table `reference_types`
--

CREATE TABLE `reference_types` (
  `id` int(11) NOT NULL,
  `type` varchar(42) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reference_types`
--

INSERT INTO `reference_types` (`id`, `type`) VALUES
(1, 'weblink'),
(2, 'printed publication'),
(3, 'online publication'),
(4, 'unpublished source'),
(5, 'other'),
(6, 'profession thesaurus');
