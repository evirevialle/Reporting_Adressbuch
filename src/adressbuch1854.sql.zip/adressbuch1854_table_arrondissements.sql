
-- --------------------------------------------------------

--
-- Table structure for table `arrondissements`
--

CREATE TABLE `arrondissements` (
  `id` int(11) NOT NULL,
  `no` smallint(6) DEFAULT NULL,
  `insee_citycode` mediumint(9) DEFAULT NULL,
  `type` varchar(120) DEFAULT NULL,
  `postcode` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `arrondissements`
--

INSERT INTO `arrondissements` (`id`, `no`, `insee_citycode`, `type`, `postcode`) VALUES
(1, 1, 75101, 'post1860', 75001),
(2, 2, 75102, 'post1860', 75002),
(3, 3, 75103, 'post1860', 75003),
(4, 4, 75104, 'post1860', 75004),
(5, 5, 75105, 'post1860', 75005),
(6, 6, 75106, 'post1860', 75006),
(7, 7, 75107, 'post1860', 75007),
(8, 8, 75108, 'post1860', 75008),
(9, 9, 75109, 'post1860', 75009),
(10, 10, 75110, 'post1860', 75010),
(11, 11, 75111, 'post1860', 75011),
(12, 12, 75112, 'post1860', 75012),
(13, 13, 75113, 'post1860', 75013),
(14, 14, 75114, 'post1860', 75014),
(15, 15, 75115, 'post1860', 75015),
(16, 16, 75116, 'post1860', 75016),
(17, 17, 75117, 'post1860', 75017),
(18, 18, 75118, 'post1860', 75018),
(19, 19, 75119, 'post1860', 75019),
(20, 20, 75120, 'post1860', 75020),
(21, 1, NULL, 'pre1860', NULL),
(22, 2, NULL, 'pre1860', NULL),
(23, 3, NULL, 'pre1860', NULL),
(24, 4, NULL, 'pre1860', NULL),
(25, 5, NULL, 'pre1860', NULL),
(26, 6, NULL, 'pre1860', NULL),
(27, 7, NULL, 'pre1860', NULL),
(28, 8, NULL, 'pre1860', NULL),
(29, 9, NULL, 'pre1860', NULL),
(30, 10, NULL, 'pre1860', NULL),
(31, 11, NULL, 'pre1860', NULL),
(32, 12, NULL, 'pre1860', NULL),
(33, 33, NULL, 'communes annexées', NULL);
